#ifndef S_C_FIFO
#define S_C_FIFO
#include <string.h> 
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <time.h>

/*definition of constants and macros common to clients and servers*/
#define NMAX 30
#define fifo1 "fifo1 "
#define fifo2 "fifo2 "

/*data structure for a question*/
struct question{
int pid_client;
int q;
};
/*data structure for a response */
 struct reponse{
int pid_serveur;
int R[NMAX];
};
# endif
