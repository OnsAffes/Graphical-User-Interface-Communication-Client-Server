#include "serv_cli_fifo.h"
#include "Handlers_Serv.h"
int main(){
/*Déclarations */

int d_quest,d_rep; /* Descripteurs sur les tubes*/
struct question quest;
struct reponse rep; 

/* Création des tubes nommés */

int f1 = mkfifo(fifo1, 0666);
int f2 = mkfifo(fifo2, 0666);

/*initialisation du générateur de nombres aléatoires*/

printf("Mon pid=%d et j'attends une question\n",getpid());
srand(getpid());

/* Ouverture des tubes nommés */
/* Attente des ouvertures Clients */
d_quest=open(fifo1,O_RDONLY);
d_rep=open(fifo2,O_WRONLY);

/* Installation des Handlers */

signal(SIGUSR1,hand_reveil);
for (int sig=1;sig<NSIG;sig++)
   {    
   	if(sig !=SIGUSR1)
   	{
	signal(sig,fin_serveur);
	}
    }

while(1){

/* lecture d’une question */
fflush(stdout);
if(read(d_quest,&quest,sizeof(struct question))!=0)
{
printf("Le PID du client=%d \n",quest.pid_client);
printf("La nombre demandé par le client=%d \n",quest.q);
printf("\n <><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>\n");
/* construction de la réponse */
for (int ind=0;ind<quest.q;ind++){
rep.R[ind]=rand()%10;
}
rep.pid_serveur=getpid();

/* envoi de la réponse */

write(d_rep,&rep,sizeof(struct reponse));

/* envoi du signal SIGUSR1 au client concerné */

kill(quest.pid_client,SIGUSR1);
pause();

}
}
return 0;
}
