#include"serv_cli_fifo.h"
#include"Handlers_Cli.h"

int main(){
/* Déclarations */

int d_quest, d_rep ;
struct question quest;
struct reponse rep;
 
/* Ouverture des tubes nommés */

d_quest=open(fifo1,O_WRONLY);
d_rep=open(fifo2,O_RDONLY);

/* Installation des Handlers */

signal(SIGUSR1,hand_reveil);

/* Construction et envoi d’une question */

quest.pid_client=getpid();
printf("Mon PID est: %d \n",quest.pid_client);
srand(getpid());
quest.q=(rand()%NMAX)+1;
write(d_quest,&quest,sizeof(struct question));  //si on écrit dans le tube 
close(d_quest);

/* Attente de la réponse */
printf("j'attends la réponse de la part du serveur\n");
fflush (stdout);
pause();

/* Lecture de la réponse */

if(read(d_rep,&rep,sizeof(struct reponse))==0){
printf("Erreur dans la lecture de la réponse\n ");
exit(5);
};
printf("\nVous avez demandé %d nombres \n",quest.q);
printf("\n<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>\n");
/* Envoi du signal SIGUSR1 au serveur */

kill(rep.pid_serveur,SIGUSR1);

/* Traitement local de la réponse */

for(int i=0;i<quest.q;i++){
printf("Le nombre n°%d=%d \n",i,rep.R[i]);
}
printf("\n<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>\n");
printf("Le PID du serveur=%d \n",rep.pid_serveur);
printf("\nChanger le type de Communication à travers l'interface\n");
close(d_rep);
return 0;

}
