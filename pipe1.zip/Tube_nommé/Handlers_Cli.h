#include "serv_cli_fifo.h"

void hand_reveil(int sig){
printf("Veuillez me donner le nombre\n");
signal(SIGUSR1,hand_reveil);
}

