#include "serv_cli_fifo.h"
void hand_reveil (int sig)
{
printf("Prochain Client\n");
signal(SIGUSR1,hand_reveil);
}
void fin_serveur (int sig)
{
unlink(fifo1);
unlink(fifo2);
printf("FIN %d \n",sig);
exit (0);
}





