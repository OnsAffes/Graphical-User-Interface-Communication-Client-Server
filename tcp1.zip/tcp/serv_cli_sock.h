#ifndef _SERV_CLI_SOCK_H
#define _SERV_CLI_SOCK_H
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include<signal.h>
#include<sys/stat.h>
#define PORT 7000
#define NMAX 30
//definition de la stucture question et reponse
struct question
{
	int pid_c; // pid_client
	int nombre;// nombre aleatoire donné par client
};
//definition de la stucture réponse
struct reponse
{
	int pid_s; //pid serveur
	int tab[NMAX];//tableau qui contient n nombre génere
};


#endif
