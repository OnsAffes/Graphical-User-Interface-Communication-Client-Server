#include "serv_cli_sock.h"
void main()
{
    int socket_server, sock_client;
    struct sockaddr_in address_server, address_client;
    //char buffer[1024];
    int i;
    struct question question; // variable question struct
    struct reponse reponse;   //vraiable reponse struct
    //création socket
    socket_server = socket(AF_INET, SOCK_STREAM, 0); //internet, socket tcp,protocole, ip protocoletcp descripteur socket TCP
    if (socket_server < 0)
    {
      printf("Echec dans la création du socket\n"); // si erreur lors de la création du socket
      exit(0);
    }
    printf("Création du socket avec succès..\n"); // Socket créé

    memset(&address_server,'\n',sizeof(address_server));//association adresse IP et num port
    //buffer(&address_server, sizeof(address_server))
    // assign IP, PORT
    address_server.sin_family = AF_INET; //premier champs
    address_server.sin_port = htons(PORT); //2eme champs numero du port 
    address_server.sin_addr.s_addr = inet_addr("127.0.0.1"); //adresse IP sous forme de chaine 
    //bind 
    int bd = bind(socket_server, (struct sockaddr *)&address_server, sizeof(address_server)); //associé adresse IP et num du port 
    if (bd < 0)
     { printf("La création du socket bind a échoué\n");
      exit(0);}
    printf("Création socket bind avec succès...\n");

    //Écoute de connexion
    if ((listen(socket_server, 15)) != 0) //socket reste en écoute 15 fois 
     {
       printf("Échec dans l'écoute\n");
       exit(0);
    }
    printf("\n Je suis le serveur dont mon pid=%d et je suis en attente de requêtes....\n", getpid());


    //accepter la connexion
    while (1)
    {
        socklen_t addrs_size = sizeof(address_client);
        sock_client = accept(socket_server, (struct sockaddr *)&address_client, &addrs_size);
        if (sock_client < 0) //tester si le serveur à accepter ou non la connexion 
         {
          printf("échec d'acceptation depuis le serveur");
          exit(0);
         }
        printf("\n Client accepté \n");
        printf("\n");
        //recevoir de la question depuis le client 
        recv(sock_client, &question, sizeof(struct question), 0);
        int pid = fork();
        printf("\n Le client dont le pid=%d est connecté au serveur", question.pid_c);
        printf("\n <><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>\n");
        if (pid < 0)
        {
             perror("erreur dans fork");
             exit(1);
        }
        
        if (pid == 0) {
         srand(getpid());       
		
        for (i = 0; i < question.nombre; i++) // boucle pour génerer le tableau d'entier aleatoirement
		{   const int temp = rand() % NMAX;
		    reponse.tab[i] = temp;
		}
                reponse.pid_s = getpid();
		write(sock_client, &reponse, sizeof(struct reponse));//envoie de la réponse au client
		exit(0);
	    		}
		else {
		close(sock_client);
		}
               
	    }
    //fermeture
    close(socket_server);
    close(sock_client);
}
