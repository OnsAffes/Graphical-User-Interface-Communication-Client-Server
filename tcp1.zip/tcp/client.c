#include "serv_cli_sock.h"
void main()
{   
//déclaration des variables 
    int socket_client;
    struct sockaddr_in addr;
    int i;//compteur
    char buffer[1024];
    struct question question; // variable question
    struct reponse reponse;//variable reponse
    //creation socket
    socket_client = socket(AF_INET, SOCK_STREAM, 0);
    if (socket_client < 0)
    {
      printf("la création du socket a échoué\n");
      exit(0);
    }
    printf("\nSocket créé avec succès\n");

    //demande de connexion
    memset(&addr, '\n', sizeof(addr));
    //buffer(&add,sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(PORT);
    addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    
    // connect the client socket to server socket
    if (connect(socket_client, (struct sockaddr *)&addr, sizeof(addr))!= 0) //envoyé une demande de connexion au serveur
    {
    printf("la connexion avec le serveur a échoué\n");
    exit(0);
    }
    else
    printf("\nConnexion au serveur établie avec succès\n");
    //transfert des donnéés
    srand(getpid());
    question.pid_c=getpid();
    question.nombre=1+ rand()%NMAX;

    send(socket_client, &question, sizeof(struct question), 0);//envoyer la question vers le serveur (0 envoie des données normales/pas prioritaires
   //réception de la réponse
    read(socket_client, &reponse, sizeof(struct reponse)); //recevoir la réponse
    /* Traitement local de la réponse */
    printf("\nVous avez demandé %d nombres:\n", question.nombre);
    printf("\n<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>");
    for ( i =0; i < question.nombre ; i ++)
      {
      printf ("\nLe nombre n°%d=%d",i,reponse.tab[i]);
      
      }
      printf("\n");
      printf("\n<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>");
    //fermeture socket
    close(socket_client);
    printf("\nChanger le type de Communication à travers l'interface\n");
}
